/* Functions referencing CAN-C (0xFFE60000..0xFFE6FFFF) */

/* CAN-C access ranking (func : #register refs):
 *   FUN_0001f5b0 : 42
 *   FUN_0001eb2a : 34
 *   (none) : 18
 *   FUN_0001f76a : 9
 *   FUN_0001d11a : 8
 *   FUN_0001a3b4 : 8
 *   FUN_0001b740 : 6
 *   FUN_0000729c : 6
 *   FUN_00012e50 : 6
 *   FUN_0002175e : 6
 *   FUN_00012dde : 4
 *   FUN_0001cd48 : 4
 *   FUN_000b7f64 : 3
 *   FUN_00019966 : 3
 *   FUN_0001cef8 : 3
 *   FUN_0001d996 : 3
 *   FUN_0001b638 : 3
 *   FUN_0001c5ac : 2
 *   FUN_0001bdd4 : 2
 *   FUN_0001ccda : 2
 *   FUN_0001d96e : 2
 *   FUN_0001ca8a : 2
 *   FUN_00012e8e : 2
 *   FUN_00007280 : 2
 *   FUN_0001b718 : 2
 *   FUN_0001c428 : 2
 *   FUN_0001b5f8 : 2
 *   FUN_0001ce48 : 2
 *   FUN_0001b8f2 : 2
 *   FUN_0001bd38 : 2
 *   FUN_00012e44 : 1
 *   FUN_0001da50 : 1
 *   FUN_0001cb80 : 1
 *   FUN_0001cd14 : 1
 *   FUN_0001da5c : 1
 *   FUN_0001c388 : 1
 *   FUN_0001da64 : 1
 *   FUN_000042ee : 1
 *   FUN_000b7e68 : 1
 *   FUN_0001ceda : 1
 *   FUN_0001da38 : 1
 *   FUN_0001b5d2 : 1
 *   FUN_0001da6e : 1
 *   FUN_0000124c : 1
 */

/* ===== FUN_0000124c @ 0x124c ===== */

undefined4 FUN_0000124c(void)

{
  undefined4 uVar1;
  
  uVar1 = DAT_ffe60220;
  return uVar1;
}


/* ===== FUN_000042ee @ 0x42ee ===== */

undefined4 FUN_000042ee(void)

{
  undefined4 uVar1;
  
  uVar1 = DAT_ffe60220;
  return uVar1;
}


/* ===== FUN_00007280 @ 0x7280 ===== */

void FUN_00007280(void)

{
  ushort uVar1;
  
  uVar1 = DAT_ffe60000;
  DAT_ffe60000 = uVar1 | 0x80;
  return;
}


/* ===== FUN_0000729c @ 0x729c ===== */

void FUN_0000729c(uint param_1,undefined2 param_2)

{
  undefined2 uVar1;
  int unaff_tp;
  undefined2 *puVar2;
  uint uVar3;
  
  param_1 = param_1 & 0xff;
  uVar1 = *(undefined2 *)(param_1 * 2 + unaff_tp + 0xf1c);
  if (param_1 < 8) {
    puVar2 = &DAT_ffe63900;
    uVar3 = param_1;
  }
  else {
    puVar2 = (undefined2 *)((int)&DAT_ffe63900 + 1);
    uVar3 = param_1 - 8 & 0xff;
  }
  FUN_000042cc(puVar2,uVar3);
  *(undefined2 *)(&DAT_ffe63914 + param_1 * 0x10) = 0;
  *(undefined2 *)(&DAT_ffe63918 + param_1 * 0x10) = param_2;
  FUN_00006e74(uVar1);
  FUN_00006eca(uVar1,1);
  if (param_1 < 8) {
    puVar2 = &DAT_ffe63900;
  }
  else {
    puVar2 = (undefined2 *)((int)&DAT_ffe63900 + 1);
    param_1 = param_1 - 8 & 0xff;
  }
  FUN_000042c6(puVar2,param_1);
  return;
}


/* ===== FUN_00012dde @ 0x12dde ===== */

void FUN_00012dde(uint param_1,char param_2)

{
  byte bVar1;
  byte bVar2;
  byte *pbVar3;
  uint in_PSW;
  
  if (param_2 == '\x01') {
    __disable_irq();
    pbVar3 = &DAT_ffe60204;
    bVar1 = DAT_ffe60204;
    bVar2 = (byte)(1 << (param_1 & 0x1f));
  }
  else {
    if (param_2 != '\x02') {
      return;
    }
    __disable_irq();
    pbVar3 = &DAT_ffe60206;
    bVar1 = DAT_ffe60206;
    bVar2 = (byte)(1 << (param_1 & 0x1f));
  }
  *pbVar3 = bVar1 | 0x80 | bVar2;
  if ((in_PSW & 0x20) == 0) {
    __enable_irq();
  }
  return;
}


/* ===== FUN_00012e44 @ 0x12e44 ===== */

void FUN_00012e44(uint param_1,undefined2 param_2)

{
  *(undefined2 *)(&DAT_ffe60246 + (param_1 & 0xff) * 0x20) = param_2;
  return;
}


/* ===== FUN_00012e50 @ 0x12e50 ===== */

void FUN_00012e50(uint param_1,char param_2)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  
  if (param_2 == '\x01') {
    bVar2 = DAT_ffe6020c;
    bVar3 = (byte)(1 << (param_1 & 0x1f));
    bVar1 = ~bVar3;
    DAT_ffe6020c = bVar3 | bVar2 & bVar1;
    bVar2 = DAT_ffe6020e;
    DAT_ffe6020e = bVar2 & bVar1;
    return;
  }
  if (param_2 == '\x02') {
    bVar1 = DAT_ffe6020c;
    DAT_ffe6020c = bVar1 & ~(byte)(1 << (param_1 & 0x1f));
  }
  return;
}


/* ===== FUN_00012e8e @ 0x12e8e ===== */

void FUN_00012e8e(uint param_1,uint param_2)

{
  ushort uVar1;
  uint uVar2;
  uint in_PSW;
  
  __disable_irq();
  uVar1 = DAT_ffe60210;
  uVar2 = (param_1 & 0xff) << 1;
  DAT_ffe60210 = (ushort)((param_2 & 0xff) << (uVar2 & 0x1f)) |
                 uVar1 & ~(ushort)(3 << (uVar2 & 0x1f));
  if ((in_PSW & 0x20) == 0) {
    __enable_irq();
  }
  return;
}


/* ===== FUN_00019966 @ 0x19966 ===== */

void FUN_00019966(void)

{
  ushort uVar1;
  int unaff_gp;
  int unaff_tp;
  int iVar2;
  uint uVar3;
  
  uVar3 = 0;
  DAT_ffe61104 = 0x5500;
  uVar1 = DAT_ffe61100;
  DAT_ffe61100 = uVar1 & 0xbfff;
  do {
    iVar2 = uVar3 + unaff_gp;
    (&DAT_ffff93b8)[iVar2] = 1;
    (&DAT_ffff93e0)[iVar2] = 0;
    FUN_00019896(uVar3);
    (&DAT_ffff93e0)[iVar2] = (&DAT_ffff93e0)[iVar2] | 0x80;
    FUN_000256c6(*(undefined4 *)(&DAT_ffffa4a0 + uVar3 * 4 + unaff_tp),0);
    FUN_0001ce48((&DAT_ffffa484)[uVar3 + unaff_tp],6);
    uVar3 = uVar3 + 1;
  } while (uVar3 < 4);
  (&DAT_ffff93fc)[unaff_gp] = 0;
  return;
}


/* ===== FUN_0001a3b4 @ 0x1a3b4 ===== */

void FUN_0001a3b4(void)

{
  byte bVar1;
  ushort uVar2;
  byte bVar3;
  int unaff_gp;
  int unaff_tp;
  byte bVar4;
  char cVar5;
  uint uVar6;
  byte *pbVar7;
  byte bVar8;
  undefined1 uVar9;
  
  bVar1 = (&DAT_ffff968a)[unaff_gp];
  *(undefined4 *)(&DAT_ffff9444 + unaff_gp) = 0xffff;
  FUN_00046f14();
  FUN_00047698();
  bVar4 = (&DAT_ffffa4f4)[unaff_tp] & 3;
  uVar6 = FUN_0004775a(bVar4);
  if (uVar6 < 0x30) {
    bVar4 = FUN_0004775a(bVar4);
  }
  else {
    cVar5 = FUN_0004775a(bVar4);
    bVar4 = cVar5 - 0x30;
  }
  (&DAT_ffff9544)[unaff_gp] = bVar4;
  bVar3 = (&DAT_ffffa4e4)[unaff_tp];
  bVar8 = bVar3;
  if (bVar3 < bVar4) {
    bVar8 = bVar3 + 0x30;
  }
  cVar5 = bVar8 - bVar4;
  (&DAT_ffff953c)[unaff_gp] = cVar5;
  pbVar7 = &DAT_ffff9408 + unaff_gp;
  if (cVar5 == '\0') {
    bVar8 = 0;
    uVar9 = 0;
  }
  else {
    bVar8 = cVar5 - 1;
    bVar3 = bVar4 + 1;
    uVar9 = (undefined1)(((uint)bVar8 * 0xf00) / 0x2d0);
  }
  (&DAT_ffff9410)[unaff_gp] = bVar8;
  *pbVar7 = bVar3;
  (&DAT_ffff9418)[unaff_gp] = uVar9;
  if (0x2f < bVar3) {
    *pbVar7 = bVar3 - 0x30;
  }
  FUN_0001a1fe(pbVar7,&DAT_ffff9410 + unaff_gp);
  if (bVar1 < 0x30) {
    bVar4 = (bVar4 + 0x30) - bVar1;
    if (0x2f < bVar4) {
      bVar4 = bVar4 - 0x30;
    }
    if ((bVar1 == 0) || (bVar1 == 0x18)) {
      cVar5 = bVar4 + 3;
    }
    else {
      cVar5 = bVar4 + 1;
    }
  }
  else {
    cVar5 = FUN_0001a28c(bVar4);
  }
  (&DAT_ffff9514)[unaff_gp] = cVar5;
  (&DAT_ffff9438)[unaff_gp] = 1;
  (&DAT_ffff9554)[unaff_gp] = 0;
  (&DAT_ffff9420)[unaff_gp] = 0;
  (&DAT_ffff954c)[unaff_gp] = 0;
  (&DAT_ffff9428)[unaff_gp] = 0;
  *(undefined4 *)(&DAT_ffff946c + unaff_gp) = 0;
  (&DAT_ffff9430)[unaff_gp] = 0;
  (&DAT_ffff951c)[unaff_gp] = 0;
  (&DAT_ffff9524)[unaff_gp] = 0;
  (&DAT_ffff952c)[unaff_gp] = 0;
  (&DAT_ffff955c)[unaff_gp] = 1;
  (&DAT_ffff9564)[unaff_gp] = 1;
  FUN_0001ce48((&DAT_ffffa4ec)[unaff_tp],6);
  DAT_ffe61306 = 0x1111;
  DAT_ffe61406 = 0x1111;
  DAT_ffe61302 = 0x4444;
  DAT_ffe61402 = 0x4444;
  uVar2 = DAT_ffe61300;
  DAT_ffe61300 = uVar2 & 0xbfff;
  uVar2 = DAT_ffe61400;
  DAT_ffe61400 = uVar2 & 0xbfff;
  return;
}


/* ===== FUN_0001b5d2 @ 0x1b5d2 ===== */

bool FUN_0001b5d2(uint param_1)

{
  int unaff_tp;
  int iVar1;
  
  iVar1 = (param_1 & 0xff) * 3 + unaff_tp;
  return ((uint)(byte)(&DAT_ffe6110a)[(uint)(byte)(&DAT_ffff9c88)[iVar1] * 0x100] &
         1 << ((byte)(&DAT_ffff9c89)[iVar1] & 0x1f)) != 0;
}


/* ===== FUN_0001b5f8 @ 0x1b5f8 ===== */

void FUN_0001b5f8(uint param_1)

{
  int unaff_tp;
  int iVar1;
  
  iVar1 = (param_1 & 0xff) * 3 + unaff_tp;
  (&DAT_ffe61108)[(uint)(byte)(&DAT_ffff9c88)[iVar1] * 0x100] =
       (&DAT_ffe61108)[(uint)(byte)(&DAT_ffff9c88)[iVar1] * 0x100] |
       (byte)(1 << ((byte)(&DAT_ffff9c89)[iVar1] & 0x1f));
  return;
}


/* ===== FUN_0001b638 @ 0x1b638 ===== */

void FUN_0001b638(uint param_1)

{
  int iVar1;
  int unaff_tp;
  byte *pbVar2;
  
  pbVar2 = &DAT_ffff9c88 + (param_1 & 0xff) * 3 + unaff_tp;
  if (pbVar2[2] == 1) {
    iVar1 = 0x10;
  }
  else {
    iVar1 = 1;
  }
  *(ushort *)(&DAT_ffe6110e + (uint)*pbVar2 * 0x100) =
       *(ushort *)(&DAT_ffe6110e + (uint)*pbVar2 * 0x100) | (ushort)(iVar1 << (pbVar2[1] & 0x1f));
  __synchronize();
  return;
}


/* ===== FUN_0001b718 @ 0x1b718 ===== */

uint FUN_0001b718(uint param_1)

{
  int unaff_tp;
  uint uVar1;
  int iVar2;
  
  iVar2 = (param_1 & 0xff) * 3 + unaff_tp;
  if ((&DAT_ffff9c8a)[iVar2] == '\x01') {
    uVar1 = *(uint *)(&DAT_ffe61120 + (uint)(byte)(&DAT_ffff9c88)[iVar2] * 0x100);
  }
  else {
    uVar1 = *(uint *)(&DAT_ffe61124 + (uint)(byte)(&DAT_ffff9c88)[iVar2] * 0x100);
  }
  return uVar1 >> 3;
}


/* ===== FUN_0001b740 @ 0x1b740 ===== */

void FUN_0001b740(uint param_1,char param_2)

{
  int unaff_tp;
  uint uVar1;
  uint uVar2;
  byte *pbVar3;
  
  pbVar3 = &DAT_ffff9c88 + (param_1 & 0xff) * 3 + unaff_tp;
  uVar2 = (uint)*pbVar3;
  if (pbVar3[2] == 1) {
    uVar1 = (uint)pbVar3[1] << 1;
    (&DAT_ffe61104)[uVar2 * 0x80] =
         (&DAT_ffe61104)[uVar2 * 0x80] & ~(ushort)(3 << (uVar1 & 0x1f)) |
         (ushort)((uint)(param_2 == '\x01') * 2 + (uint)(param_2 != '\x01') << (uVar1 & 0x1f));
  }
  else {
    uVar1 = (uint)pbVar3[1] << 2;
    *(ushort *)(&DAT_ffe61106 + uVar2 * 0x100) =
         *(ushort *)(&DAT_ffe61106 + uVar2 * 0x100) & ~(ushort)(7 << (uVar1 & 0x1f)) |
         (ushort)((uint)(param_2 == '\x01') * 2 + (uint)(param_2 != '\x01') << (uVar1 & 0x1f));
  }
  __synchronize();
  return;
}


/* ===== FUN_0001b8f2 @ 0x1b8f2 ===== */

void FUN_0001b8f2(uint param_1)

{
  int unaff_tp;
  int iVar1;
  
  iVar1 = (param_1 & 0xffff) * 2 + unaff_tp;
  (&DAT_ffe61108)[(uint)(byte)(&DAT_ffff9d2c)[iVar1] * 0x100] =
       (&DAT_ffe61108)[(uint)(byte)(&DAT_ffff9d2c)[iVar1] * 0x100] |
       (byte)(1 << ((byte)(&DAT_ffff9d2d)[iVar1] & 0x1f));
  return;
}


/* ===== FUN_0001bd38 @ 0x1bd38 ===== */

void FUN_0001bd38(void)

{
  ushort uVar1;
  uint uVar2;
  int unaff_gp;
  
  (&DAT_ffff968a)[unaff_gp] = 0xff;
  (&DAT_ffff968b)[unaff_gp] = 0xff;
  *(undefined4 *)(&DAT_ffff9678 + unaff_gp) = 0xfffffff;
  *(undefined4 *)(&DAT_ffff967c + unaff_gp) = 0xffffffff;
  *(undefined4 *)(&DAT_ffff95ac + unaff_gp) = 0xffffffff;
  (&DAT_ffff968c)[unaff_gp] = 0;
  uVar2 = 0;
  (&DAT_ffff968d)[unaff_gp] = 0;
  (&DAT_ffff968e)[unaff_gp] = 0;
  (&DAT_ffff9693)[unaff_gp] = 0;
  (&DAT_ffff9694)[unaff_gp] = 0;
  do {
    *(undefined2 *)(&DAT_ffff9684 + uVar2 * 2 + unaff_gp) = 0xffff;
    uVar2 = uVar2 + 1;
  } while (uVar2 < 3);
  uVar1 = DAT_ffe61500;
  (&DAT_ffff95b4)[unaff_gp] = 0;
  (&DAT_ffff9698)[unaff_gp] = 0;
  (&DAT_ffff968f)[unaff_gp] = 0;
  (&DAT_ffff9690)[unaff_gp] = 0;
  (&DAT_ffff9691)[unaff_gp] = 0;
  (&DAT_ffff9692)[unaff_gp] = 0;
  *(undefined2 *)(&DAT_ffff9680 + unaff_gp) = 0xffff;
  DAT_ffe61500 = uVar1 & 0xbfff;
  FUN_00012dde(4,1);
  FUN_00012e8e(4,1);
  FUN_00012e50(4,2);
  FUN_00012e44(4,0x140);
  FUN_0001b92e();
  return;
}


/* ===== FUN_0001bdd4 @ 0x1bdd4 ===== */

void FUN_0001bdd4(void)

{
  undefined1 uVar1;
  
  DAT_ffe6020a = 0xbf;
  uVar1 = DAT_ffe6020a;
  __synchronize();
  FUN_0001b988();
  FUN_00012ece(4);
  FUN_00012f0a(4,1);
  FUN_0001b918(0x13);
  FUN_0001b8ba(0x13,1);
  FUN_0001b620(0x24,1);
  FUN_0001b7b6(0x24);
  return;
}


/* ===== FUN_0001c388 @ 0x1c388 ===== */

void FUN_0001c388(uint param_1,char param_2)

{
  if (param_2 == '\0') {
    FUN_00026b50();
    __synchronize();
  }
  else {
    FUN_00026b4a(&DAT_ffe62116 + ((param_1 & 0xff) >> 2) * 0x80);
    FUN_0001d87c((param_1 & 0xff) + 0xf2,1);
  }
  return;
}


/* ===== FUN_0001c428 @ 0x1c428 ===== */

void FUN_0001c428(uint param_1)

{
  *(short *)(&DAT_ffe62112 + ((param_1 & 0xff) >> 2) * 0x100) = (short)(1 << (param_1 & 3));
  __synchronize();
  return;
}


/* ===== FUN_0001c5ac @ 0x1c5ac ===== */

void FUN_0001c5ac(uint param_1,char param_2)

{
  byte bVar1;
  int iVar2;
  
  iVar2 = ((param_1 & 0xff) >> 2) * 0x100;
  if (param_2 == '\x01') {
    bVar1 = (&DAT_ffe62114)[iVar2] | (byte)(1 << (param_1 & 3));
  }
  else {
    bVar1 = (&DAT_ffe62114)[iVar2] & ~(byte)(1 << (param_1 & 3));
  }
  (&DAT_ffe62114)[iVar2] = bVar1;
  return;
}


/* ===== FUN_0001ca8a @ 0x1ca8a ===== */

void FUN_0001ca8a(uint param_1,ushort param_2)

{
  ushort uVar1;
  int iVar2;
  uint in_PSW;
  
  __disable_irq();
  uVar1 = (ushort)(1 << (param_1 & 3));
  iVar2 = ((param_1 & 0xff) >> 2) * 0x100;
  *(ushort *)(&DAT_ffe6210c + iVar2) =
       (param_2 & 0xff) * uVar1 + (*(ushort *)(&DAT_ffe6210c + iVar2) & ~uVar1) + -0x6400;
  if ((in_PSW & 0x20) == 0) {
    __enable_irq();
  }
  return;
}


/* ===== FUN_0001cb80 @ 0x1cb80 ===== */

void FUN_0001cb80(uint param_1,undefined2 param_2)

{
  *(undefined2 *)(&DAT_ffe63058 + (param_1 & 0x3f) * 0x40) = param_2;
  return;
}


/* ===== FUN_0001ccda @ 0x1ccda ===== */

void FUN_0001ccda(uint param_1)

{
  (&DAT_ffe63046)[(param_1 & 0x3f) * 0x40] = 4;
  __synchronize();
  return;
}


/* ===== FUN_0001cd14 @ 0x1cd14 ===== */

void FUN_0001cd14(uint param_1,undefined2 param_2)

{
  if ((param_1 & 0xff) >> 6 == 1) {
    *(undefined2 *)(&DAT_ffe6304a + (param_1 & 0x3f) * 0x40) = param_2;
    return;
  }
  *(undefined2 *)(&UNK_ffe60672 + (param_1 & 3) * 4 + ((param_1 & 0x3f) >> 2) * 0x80) = param_2;
  return;
}


/* ===== FUN_0001cd48 @ 0x1cd48 ===== */

void FUN_0001cd48(uint param_1,char param_2)

{
  int iVar1;
  
  iVar1 = (param_1 & 0x3f) * 0x40;
  (&DAT_ffe63042)[iVar1] = 0;
  (&DAT_ffe63044)[iVar1] = 0x77;
  (&DAT_ffe63040)[iVar1] = ((&DAT_ffe63040)[iVar1] & 0xe0) + param_2 + '\x14';
  return;
}


/* ===== FUN_0001ce48 @ 0x1ce48 ===== */

void FUN_0001ce48(uint param_1,ushort param_2)

{
  int iVar1;
  int iVar2;
  uint in_PSW;
  
  __disable_irq();
  iVar2 = ((param_1 & 0x3f) >> 2) * 0x80;
  iVar1 = (param_1 & 3) << 2;
  *(ushort *)(&DAT_ffe60628 + iVar2) =
       (short)(1 << iVar1) * (param_2 & 0xff) |
       ~(ushort)(0xf << iVar1) & *(ushort *)(&DAT_ffe60628 + iVar2);
  if ((in_PSW & 0x20) == 0) {
    __enable_irq();
  }
  return;
}


/* ===== FUN_0001ceda @ 0x1ceda ===== */

uint FUN_0001ceda(uint param_1)

{
  return (uint)*(ushort *)(&DAT_ffe60626 + ((param_1 & 0x3f) >> 2) * 0x80) & 1 << (param_1 & 3) &
         0xff;
}


/* ===== FUN_0001cef8 @ 0x1cef8 ===== */

void FUN_0001cef8(uint param_1)

{
  int iVar1;
  
  iVar1 = ((param_1 & 0x3f) >> 2) * 0x80;
  *(ushort *)(&DAT_ffe60622 + iVar1) =
       *(ushort *)(&DAT_ffe60622 + iVar1) | (ushort)(1 << (param_1 & 3));
  __synchronize();
  return;
}


/* ===== FUN_0001d11a @ 0x1d11a ===== */

void FUN_0001d11a(uint param_1,ushort param_2)

{
  int unaff_tp;
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint in_PSW;
  
  uVar2 = param_1 & 3;
  __disable_irq();
  uVar1 = (param_1 & 0xff) >> 2;
  *(ushort *)(&DAT_ffe60628 + uVar1 * 0x80) =
       (short)(1 << (uVar2 << 2)) * (param_2 & 0xff) |
       ~(ushort)(0xf << (uVar2 << 2)) & *(ushort *)(&DAT_ffe60628 + uVar1 * 0x80);
  (&DAT_ffe60634)[uVar1 * 0x40] = (&DAT_ffe60634)[uVar1 * 0x40] & ~(ushort)(1 << uVar2);
  __synchronize();
  uVar3 = *(ushort *)(&DAT_ffff9d7c + uVar1 * 2 + unaff_tp) + uVar2 & 0xffff;
  FUN_0001d7ca(uVar3);
  FUN_0001d87c(uVar3,1);
  (&DAT_ffe60624)[uVar1 * 0x40] = (ushort)(0x10 << uVar2) | (&DAT_ffe60624)[uVar1 * 0x40];
  __synchronize();
  if ((in_PSW & 0x20) == 0) {
    __enable_irq();
  }
  return;
}


/* ===== FUN_0001d96e @ 0x1d96e ===== */

void FUN_0001d96e(byte param_1)

{
  undefined2 *puVar1;
  
  if (param_1 < 8) {
    puVar1 = &DAT_ffe63900;
  }
  else {
    param_1 = param_1 - 8;
    puVar1 = (undefined2 *)((int)&DAT_ffe63900 + 1);
  }
  FUN_00026b4a(puVar1,param_1);
  return;
}


/* ===== FUN_0001d996 @ 0x1d996 ===== */

void FUN_0001d996(byte param_1)

{
  undefined2 uVar1;
  undefined2 *puVar2;
  
  if (param_1 < 8) {
    puVar2 = &DAT_ffe63900;
  }
  else {
    param_1 = param_1 - 8;
    puVar2 = (undefined2 *)((int)&DAT_ffe63900 + 1);
  }
  FUN_00026b50(puVar2,param_1);
  uVar1 = DAT_ffe63900;
  __synchronize();
  return;
}


/* ===== FUN_0001da38 @ 0x1da38 ===== */

void FUN_0001da38(uint param_1,undefined2 param_2)

{
  *(undefined2 *)(&DAT_ffe63918 + (param_1 & 0xff) * 0x10) = param_2;
  return;
}


/* ===== FUN_0001da50 @ 0x1da50 ===== */

void FUN_0001da50(uint param_1,undefined2 param_2)

{
  *(undefined2 *)(&DAT_ffe63914 + (param_1 & 0xff) * 0x10) = param_2;
  return;
}


/* ===== FUN_0001da5c @ 0x1da5c ===== */

undefined4 FUN_0001da5c(void)

{
  undefined4 uVar1;
  
  uVar1 = DAT_ffe60220;
  return uVar1;
}


/* ===== FUN_0001da64 @ 0x1da64 ===== */

int FUN_0001da64(void)

{
  int iVar1;
  
  iVar1 = DAT_ffe60220;
  return iVar1 << 8;
}


/* ===== FUN_0001da6e @ 0x1da6e ===== */

int FUN_0001da6e(uint param_1)

{
  return *(int *)(&DAT_ffe60638 + ((param_1 & 0xff) >> 2) * 0x80) << 8;
}


/* ===== FUN_0001eb2a @ 0x1eb2a ===== */

void FUN_0001eb2a(void)

{
  int iVar1;
  int unaff_tp;
  int iVar2;
  int iVar3;
  int iVar4;
  
  FUN_0001ea70(&DAT_ffe60000,0x3ff);
  FUN_0001ea98(&DAT_ffe60002,4);
  FUN_0001ea98(&DAT_ffe60003,0x8e);
  FUN_0001ea70(&DAT_ffe60080,0);
  FUN_0001ea70(&DAT_ffe60084,9);
  FUN_0001ea70(&DAT_ffe60088,0);
  FUN_0001ea70(&DAT_ffe6008c,0);
  FUN_0001ea98(&DAT_ffe60200,1);
  FUN_0001eac0(&DAT_ffe60214,0x3f);
  FUN_0001ea98(&DAT_ffe60400,0x55);
  FUN_0001ea98(&DAT_ffe60600,0x3f);
  iVar4 = 0;
  do {
    FUN_0001ea98(&DAT_ffe60604 + iVar4,0xf);
    FUN_0001eae6(&DAT_ffe60624 + iVar4 * 0x40,*(undefined2 *)(&DAT_ffff9dd4 + iVar4 * 2 + unaff_tp),
                 0x10f);
    FUN_0001eac0(&DAT_ffe6063c + iVar4 * 0x40,0x1000000);
    iVar3 = iVar4 + 1;
    iVar1 = iVar4 + -5;
    iVar2 = iVar4 + -5;
    iVar4 = iVar3;
  } while (iVar1 < 0 != (iVar3 < 0 && -1 < iVar2));
  FUN_0001ea70(&DAT_ffe61000,0x1f);
  iVar4 = 0;
  do {
    iVar2 = iVar4 * 0x100;
    FUN_0001ea98(&DAT_ffe61111 + iVar2,0);
    FUN_0001ea98(&DAT_ffe61110 + iVar2,0);
    FUN_0001ea98(&DAT_ffe61114 + iVar2,(&DAT_ffff9dea)[iVar4 + unaff_tp]);
    FUN_0001eac0(&DAT_ffe61128 + iVar4 * 0x80,0x1000000);
    FUN_0001eac0(&DAT_ffe6112c + iVar4 * 0x80,0x1000000);
    FUN_0001ea98(&DAT_ffe61130 + iVar2,0);
    FUN_0001ea98(&DAT_ffe61134 + iVar2,0);
    iVar3 = iVar4 + 1;
    iVar1 = iVar4 + -4;
    iVar2 = iVar4 + -4;
    iVar4 = iVar3;
  } while (iVar1 < 0 != (iVar3 < 0 && -1 < iVar2));
  FUN_0001ea98(&DAT_ffe62000,0x7f);
  iVar4 = 0;
  do {
    FUN_0001ea98(&DAT_ffe62108 + iVar4 * 0x100,1);
    FUN_0001ea98(&DAT_ffe62104 + iVar4 * 0x100,0);
    iVar3 = iVar4 + 1;
    iVar1 = iVar4 + -6;
    iVar2 = iVar4 + -6;
    iVar4 = iVar3;
  } while (iVar1 < 0 != (iVar3 < 0 && -1 < iVar2));
  FUN_0001ea70(&DAT_ffe63000,0xfff);
  FUN_0001ea70(&DAT_ffe6300c,0xfff);
  iVar4 = 0;
  do {
    FUN_0001ea98(&DAT_ffe63910 + iVar4 * 0x10,(&DAT_ffff9def)[iVar4 + unaff_tp]);
    iVar3 = iVar4 + 1;
    iVar1 = iVar4 + -7;
    iVar2 = iVar4 + -7;
    iVar4 = iVar3;
  } while (iVar1 < 0 != (iVar3 < 0 && -1 < iVar2));
  FUN_0001ea98(&DAT_ffe60100,0x10);
  FUN_0001ea98(&DAT_ffe63c00,0);
  return;
}


/* ===== FUN_0001f5b0 @ 0x1f5b0 ===== */

void FUN_0001f5b0(void)

{
  int iVar1;
  int iVar2;
  byte bVar3;
  int iVar4;
  int iVar5;
  int unaff_tp;
  
  DAT_ffe60002 = 4;
  DAT_ffe60003 = 0x8e;
  DAT_ffe60080 = 0;
  DAT_ffe60084 = 9;
  DAT_ffe60088 = 0;
  DAT_ffe6008c = 0;
  DAT_ffe60200 = 1;
  DAT_ffe60214 = 0x3f;
  DAT_ffe60400 = 0x55;
  bVar3 = DAT_ffe60402;
  DAT_ffe60402 = bVar3 | 0x40;
  iVar5 = 0;
  do {
    (&DAT_ffe6063c)[iVar5 * 0x40] = 0;
    (&DAT_ffe60624)[iVar5 * 0x40] = *(undefined2 *)(&DAT_ffff9dd4 + iVar5 * 2 + unaff_tp);
    (&DAT_ffe60604)[iVar5] = 0xf;
    iVar4 = iVar5 + 1;
    (&DAT_ffe60634)[iVar5 * 0x40] = 0;
    iVar2 = iVar5 + -5;
    iVar1 = iVar5 + -5;
    iVar5 = iVar4;
  } while (iVar2 < 0 != (iVar4 < 0 && -1 < iVar1));
  iVar5 = 0;
  do {
    (&DAT_ffe61100)[iVar5 * 0x80] = *(undefined2 *)(&DAT_ffff9dd4 + iVar5 * 2 + unaff_tp + 0xc);
    iVar4 = iVar5 + 1;
    iVar2 = iVar5 + -4;
    iVar1 = iVar5 + -4;
    (&DAT_ffe61114)[iVar5 * 0x100] = (&DAT_ffff9dd4)[iVar5 + unaff_tp + 0x16];
    (&DAT_ffe61128)[iVar5 * 0x80] = 0;
    (&DAT_ffe6112c)[iVar5 * 0x80] = 0;
    iVar5 = iVar4;
  } while (iVar2 < 0 != (iVar4 < 0 && -1 < iVar1));
  iVar5 = 0;
  do {
    iVar4 = iVar5 + 1;
    (&DAT_ffe62108)[iVar5 * 0x100] = 1;
    (&DAT_ffe62104)[iVar5 * 0x100] = 0;
    (&DAT_ffe62116)[iVar5 * 0x80] = 0;
    iVar2 = iVar5 + -6;
    iVar1 = iVar5 + -6;
    iVar5 = iVar4;
  } while (iVar2 < 0 != (iVar4 < 0 && -1 < iVar1));
  DAT_ffe6300c = 0xfff;
  DAT_ffe63010 = 0xc901;
  iVar5 = 0;
  do {
    iVar4 = iVar5 + 1;
    (&DAT_ffe63040)[iVar5 * 0x40] = 0x20;
    (&DAT_ffe63047)[iVar5 * 0x40] = 0;
    iVar2 = iVar5 + -0xb;
    iVar1 = iVar5 + -0xb;
    iVar5 = iVar4;
  } while (iVar2 < 0 != (iVar4 < 0 && -1 < iVar1));
  iVar5 = 0;
  do {
    iVar4 = iVar5 + 1;
    iVar2 = iVar5 + -7;
    iVar1 = iVar5 + -7;
    (&DAT_ffe63910)[iVar5 * 0x10] = (&DAT_ffff9dd4)[iVar5 + unaff_tp + 0x1b];
    iVar5 = iVar4;
  } while (iVar2 < 0 != (iVar4 < 0 && -1 < iVar1));
  DAT_ffe60100 = 0x10;
  DAT_ffe60000 = 0x3ff;
  return;
}


/* ===== FUN_0001f76a @ 0x1f76a ===== */

void FUN_0001f76a(void)

{
  undefined4 uVar1;
  
  DAT_ffe60000 = 0;
  DAT_ffe60600 = 0x3f;
  DAT_ffe61000 = 0x1f;
  DAT_ffe62000 = 0x7f;
  DAT_ffe63000 = 0xfff;
  DAT_ffe63c00 = 0;
  DAT_ffe60220._0_2_ = 0;
  uVar1 = DAT_ffe60220;
  __synchronize();
  DAT_ffe60000 = 0x3ff;
  return;
}


/* ===== FUN_0002175e @ 0x2175e ===== */

void FUN_0002175e(void)

{
  DAT_ffe60000 = 0;
  DAT_ffe60600 = 0;
  DAT_ffe61000 = 0;
  DAT_ffe62000 = 0;
  DAT_ffe63000 = 0;
  DAT_ffe63c00 = 0;
  return;
}


/* ===== FUN_000b7e68 @ 0xb7e68 ===== */

undefined4 FUN_000b7e68(void)

{
  undefined4 uVar1;
  
  uVar1 = DAT_ffe60220;
  return uVar1;
}


/* ===== FUN_000b7f64 @ 0xb7f64 ===== */

void FUN_000b7f64(void)

{
  ushort uVar1;
  
  uVar1 = DAT_ffe60000;
  DAT_ffe60000 = uVar1 & 0xffef;
  DAT_ffe61000 = 0;
  return;
}


