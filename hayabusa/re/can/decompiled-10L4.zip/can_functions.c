/* Functions referencing CAN-C (0xFFE60000..0xFFE6FFFF) */

/* CAN-C access ranking (func : #register refs):
 *   FUN_0001f5b0 : 42
 *   FUN_0001eb2a : 34
 *   (none) : 18
 *   FUN_0001f76a : 9
 *   FUN_0001d11a : 8
 *   FUN_0001a3b4 : 8
 *   FUN_0001b740 : 6
 *   FUN_0000729c : 6
 *   FUN_00012e50 : 6
 *   FUN_0002175e : 6
 *   FUN_00012dde : 4
 *   FUN_0001cd48 : 4
 *   FUN_000b7f64 : 3
 *   FUN_00019966 : 3
 *   FUN_0001cef8 : 3
 *   FUN_0001d996 : 3
 *   FUN_0001b638 : 3
 *   FUN_0001c5ac : 2
 *   FUN_0001bdd4 : 2
 *   FUN_0001ccda : 2
 *   FUN_0001d96e : 2
 *   FUN_0001ca8a : 2
 *   FUN_00012e8e : 2
 *   FUN_00007280 : 2
 *   FUN_0001b718 : 2
 *   FUN_0001c428 : 2
 *   FUN_0001b5f8 : 2
 *   FUN_0001ce48 : 2
 *   FUN_0001b8f2 : 2
 *   FUN_0001bd38 : 2
 *   FUN_00012e44 : 1
 *   FUN_0001da50 : 1
 *   FUN_0001cb80 : 1
 *   FUN_0001cd14 : 1
 *   FUN_0001da5c : 1
 *   FUN_0001c388 : 1
 *   FUN_0001da64 : 1
 *   FUN_000042ee : 1
 *   FUN_000b7e68 : 1
 *   FUN_0001ceda : 1
 *   FUN_0001da38 : 1
 *   FUN_0001b5d2 : 1
 *   FUN_0001da6e : 1
 *   FUN_0000124c : 1
 */

/* ===== FUN_0000124c @ 0x124c ===== */

undefined4 FUN_0000124c(void)

{
  undefined4 uVar1;
  
  uVar1 = DAT_ffe60220;
  return uVar1;
}


/* ===== FUN_000042ee @ 0x42ee ===== */

undefined4 FUN_000042ee(void)

{
  undefined4 uVar1;
  
  uVar1 = DAT_ffe60220;
  return uVar1;
}


/* ===== FUN_00007280 @ 0x7280 ===== */

void FUN_00007280(void)

{
  ushort uVar1;
  
  uVar1 = DAT_ffe60000;
  DAT_ffe60000 = uVar1 | 0x80;
  return;
}


/* ===== FUN_0000729c @ 0x729c ===== */

void FUN_0000729c(uint param_1,undefined2 param_2)

{
  undefined2 uVar1;
  undefined2 *puVar2;
  uint uVar3;
  
  param_1 = param_1 & 0xff;
  uVar1 = *(undefined2 *)(param_1 * 2 + 0xf1c);
  if (param_1 < 8) {
    puVar2 = &DAT_ffe63900;
    uVar3 = param_1;
  }
  else {
    puVar2 = (undefined2 *)((int)&DAT_ffe63900 + 1);
    uVar3 = param_1 - 8 & 0xff;
  }
  FUN_000042cc(puVar2,uVar3);
  *(undefined2 *)(&DAT_ffe63914 + param_1 * 0x10) = 0;
  *(undefined2 *)(&DAT_ffe63918 + param_1 * 0x10) = param_2;
  FUN_00006e74(uVar1);
  FUN_00006eca(uVar1,1);
  if (param_1 < 8) {
    puVar2 = &DAT_ffe63900;
  }
  else {
    puVar2 = (undefined2 *)((int)&DAT_ffe63900 + 1);
    param_1 = param_1 - 8 & 0xff;
  }
  FUN_000042c6(puVar2,param_1);
  return;
}


/* ===== FUN_00012dde @ 0x12dde ===== */

void FUN_00012dde(uint param_1,char param_2)

{
  byte bVar1;
  byte bVar2;
  byte *pbVar3;
  uint in_PSW;
  
  if (param_2 == '\x01') {
    __disable_irq();
    pbVar3 = &DAT_ffe60204;
    bVar1 = DAT_ffe60204;
    bVar2 = (byte)(1 << (param_1 & 0x1f));
  }
  else {
    if (param_2 != '\x02') {
      return;
    }
    __disable_irq();
    pbVar3 = &DAT_ffe60206;
    bVar1 = DAT_ffe60206;
    bVar2 = (byte)(1 << (param_1 & 0x1f));
  }
  *pbVar3 = bVar1 | 0x80 | bVar2;
  if ((in_PSW & 0x20) == 0) {
    __enable_irq();
  }
  return;
}


/* ===== FUN_00012e44 @ 0x12e44 ===== */

void FUN_00012e44(uint param_1,undefined2 param_2)

{
  *(undefined2 *)(&DAT_ffe60246 + (param_1 & 0xff) * 0x20) = param_2;
  return;
}


/* ===== FUN_00012e50 @ 0x12e50 ===== */

void FUN_00012e50(uint param_1,char param_2)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  
  if (param_2 == '\x01') {
    bVar2 = DAT_ffe6020c;
    bVar3 = (byte)(1 << (param_1 & 0x1f));
    bVar1 = ~bVar3;
    DAT_ffe6020c = bVar3 | bVar2 & bVar1;
    bVar2 = DAT_ffe6020e;
    DAT_ffe6020e = bVar2 & bVar1;
    return;
  }
  if (param_2 == '\x02') {
    bVar1 = DAT_ffe6020c;
    DAT_ffe6020c = bVar1 & ~(byte)(1 << (param_1 & 0x1f));
  }
  return;
}


/* ===== FUN_00012e8e @ 0x12e8e ===== */

void FUN_00012e8e(uint param_1,uint param_2)

{
  ushort uVar1;
  uint uVar2;
  uint in_PSW;
  
  __disable_irq();
  uVar1 = DAT_ffe60210;
  uVar2 = (param_1 & 0xff) << 1;
  DAT_ffe60210 = (ushort)((param_2 & 0xff) << (uVar2 & 0x1f)) |
                 uVar1 & ~(ushort)(3 << (uVar2 & 0x1f));
  if ((in_PSW & 0x20) == 0) {
    __enable_irq();
  }
  return;
}


/* ===== FUN_00019966 @ 0x19966 ===== */

void FUN_00019966(void)

{
  ushort uVar1;
  undefined8 uVar2;
  int iVar3;
  uint uVar4;
  
  uVar2 = 0;
  uVar4 = 0;
  DAT_ffe61104 = 0x5500;
  uVar1 = DAT_ffe61100;
  DAT_ffe61100 = uVar1 & 0xbfff;
  do {
    iVar3 = uVar4 + (int)uVar2;
    (&DAT_ffff93b8)[iVar3] = 1;
    (&DAT_ffff93e0)[iVar3] = 0;
    FUN_00019896(uVar4);
    (&DAT_ffff93e0)[iVar3] = (&DAT_ffff93e0)[iVar3] | 0x80;
    FUN_000256c6(*(undefined4 *)(&DAT_ffffa4a0 + uVar4 * 4 + (int)((ulonglong)uVar2 >> 0x20)),0);
    FUN_0001ce48((&DAT_ffffa484)[uVar4 + (int)((ulonglong)uVar2 >> 0x20)],6);
    uVar4 = uVar4 + 1;
  } while (uVar4 < 4);
  (&DAT_ffff93fc)[(int)uVar2] = 0;
  return;
}


/* ===== FUN_0001a3b4 @ 0x1a3b4 ===== */

void FUN_0001a3b4(void)

{
  ushort uVar1;
  byte bVar2;
  byte bVar3;
  int iVar4;
  undefined8 uVar5;
  byte bVar6;
  char cVar7;
  uint uVar8;
  byte *pbVar9;
  byte bVar10;
  undefined1 uVar11;
  
  uVar5 = 0;
  bVar2 = DAT_ffff968a;
  Ramffff9444 = 0xffff;
  FUN_00046f14();
  FUN_00047698();
  bVar6 = (&DAT_ffffa4f4)[(int)((ulonglong)uVar5 >> 0x20)] & 3;
  uVar8 = FUN_0004775a(bVar6);
  if (uVar8 < 0x30) {
    bVar6 = FUN_0004775a(bVar6);
  }
  else {
    cVar7 = FUN_0004775a(bVar6);
    bVar6 = cVar7 - 0x30;
  }
  iVar4 = (int)uVar5;
  (&DAT_ffff9544)[iVar4] = bVar6;
  bVar3 = (&DAT_ffffa4e4)[(int)((ulonglong)uVar5 >> 0x20)];
  bVar10 = bVar3;
  if (bVar3 < bVar6) {
    bVar10 = bVar3 + 0x30;
  }
  cVar7 = bVar10 - bVar6;
  (&DAT_ffff953c)[iVar4] = cVar7;
  pbVar9 = &DAT_ffff9408 + iVar4;
  if (cVar7 == '\0') {
    bVar10 = 0;
    uVar11 = 0;
  }
  else {
    bVar10 = cVar7 - 1;
    bVar3 = bVar6 + 1;
    uVar11 = (undefined1)(((uint)bVar10 * 0xf00) / 0x2d0);
  }
  (&DAT_ffff9410)[iVar4] = bVar10;
  *pbVar9 = bVar3;
  (&DAT_ffff9418)[iVar4] = uVar11;
  if (0x2f < bVar3) {
    *pbVar9 = bVar3 - 0x30;
  }
  FUN_0001a1fe(pbVar9,&DAT_ffff9410 + iVar4);
  if (bVar2 < 0x30) {
    bVar6 = (bVar6 + 0x30) - bVar2;
    if (0x2f < bVar6) {
      bVar6 = bVar6 - 0x30;
    }
    if ((bVar2 == 0) || (bVar2 == 0x18)) {
      cVar7 = bVar6 + 3;
    }
    else {
      cVar7 = bVar6 + 1;
    }
  }
  else {
    cVar7 = FUN_0001a28c(bVar6);
  }
  iVar4 = (int)uVar5;
  (&DAT_ffff9514)[iVar4] = cVar7;
  (&DAT_ffff9438)[iVar4] = 1;
  (&DAT_ffff9554)[iVar4] = 0;
  (&DAT_ffff9420)[iVar4] = 0;
  (&DAT_ffff954c)[iVar4] = 0;
  (&DAT_ffff9428)[iVar4] = 0;
  *(undefined4 *)(&DAT_ffff946c + iVar4) = 0;
  (&DAT_ffff9430)[iVar4] = 0;
  (&DAT_ffff951c)[iVar4] = 0;
  (&DAT_ffff9524)[iVar4] = 0;
  (&DAT_ffff952c)[iVar4] = 0;
  (&DAT_ffff955c)[iVar4] = 1;
  (&DAT_ffff9564)[iVar4] = 1;
  FUN_0001ce48((&DAT_ffffa4ec)[(int)((ulonglong)uVar5 >> 0x20)],6);
  DAT_ffe61306 = 0x1111;
  DAT_ffe61406 = 0x1111;
  DAT_ffe61302 = 0x4444;
  DAT_ffe61402 = 0x4444;
  uVar1 = DAT_ffe61300;
  DAT_ffe61300 = uVar1 & 0xbfff;
  uVar1 = DAT_ffe61400;
  DAT_ffe61400 = uVar1 & 0xbfff;
  return;
}


/* ===== FUN_0001b5d2 @ 0x1b5d2 ===== */

bool FUN_0001b5d2(uint param_1)

{
  int iVar1;
  
  iVar1 = (param_1 & 0xff) * 3;
  return ((uint)(byte)(&DAT_ffe6110a)[(uint)(byte)(&DAT_ffff9c88)[iVar1] * 0x100] &
         1 << ((byte)(&DAT_ffff9c89)[iVar1] & 0x1f)) != 0;
}


/* ===== FUN_0001b5f8 @ 0x1b5f8 ===== */

void FUN_0001b5f8(uint param_1)

{
  int iVar1;
  
  iVar1 = (param_1 & 0xff) * 3;
  (&DAT_ffe61108)[(uint)(byte)(&DAT_ffff9c88)[iVar1] * 0x100] =
       (&DAT_ffe61108)[(uint)(byte)(&DAT_ffff9c88)[iVar1] * 0x100] |
       (byte)(1 << ((byte)(&DAT_ffff9c89)[iVar1] & 0x1f));
  return;
}


/* ===== FUN_0001b638 @ 0x1b638 ===== */

void FUN_0001b638(uint param_1)

{
  int iVar1;
  int iVar2;
  
  iVar2 = (param_1 & 0xff) * 3;
  if ((&DAT_ffff9c8a)[iVar2] == '\x01') {
    iVar1 = 0x10;
  }
  else {
    iVar1 = 1;
  }
  *(ushort *)(&DAT_ffe6110e + (uint)(byte)(&DAT_ffff9c88)[iVar2] * 0x100) =
       *(ushort *)(&DAT_ffe6110e + (uint)(byte)(&DAT_ffff9c88)[iVar2] * 0x100) |
       (ushort)(iVar1 << ((byte)(&DAT_ffff9c89)[iVar2] & 0x1f));
  __synchronize();
  return;
}


/* ===== FUN_0001b718 @ 0x1b718 ===== */

uint FUN_0001b718(uint param_1)

{
  uint uVar1;
  int iVar2;
  
  iVar2 = (param_1 & 0xff) * 3;
  if ((&DAT_ffff9c8a)[iVar2] == '\x01') {
    uVar1 = *(uint *)(&DAT_ffe61120 + (uint)(byte)(&DAT_ffff9c88)[iVar2] * 0x100);
  }
  else {
    uVar1 = *(uint *)(&DAT_ffe61124 + (uint)(byte)(&DAT_ffff9c88)[iVar2] * 0x100);
  }
  return uVar1 >> 3;
}


/* ===== FUN_0001b740 @ 0x1b740 ===== */

void FUN_0001b740(uint param_1,char param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  
  iVar3 = (param_1 & 0xff) * 3;
  uVar2 = (uint)(byte)(&DAT_ffff9c88)[iVar3];
  if ((&DAT_ffff9c8a)[iVar3] == '\x01') {
    uVar1 = (uint)(byte)(&DAT_ffff9c89)[iVar3] << 1;
    (&DAT_ffe61104)[uVar2 * 0x80] =
         (&DAT_ffe61104)[uVar2 * 0x80] & ~(ushort)(3 << (uVar1 & 0x1f)) |
         (ushort)((uint)(param_2 == '\x01') * 2 + (uint)(param_2 != '\x01') << (uVar1 & 0x1f));
  }
  else {
    uVar1 = (uint)(byte)(&DAT_ffff9c89)[iVar3] << 2;
    *(ushort *)(&DAT_ffe61106 + uVar2 * 0x100) =
         *(ushort *)(&DAT_ffe61106 + uVar2 * 0x100) & ~(ushort)(7 << (uVar1 & 0x1f)) |
         (ushort)((uint)(param_2 == '\x01') * 2 + (uint)(param_2 != '\x01') << (uVar1 & 0x1f));
  }
  __synchronize();
  return;
}


/* ===== FUN_0001b8f2 @ 0x1b8f2 ===== */

void FUN_0001b8f2(uint param_1)

{
  int iVar1;
  
  iVar1 = (param_1 & 0xffff) * 2;
  (&DAT_ffe61108)[(uint)(byte)(&DAT_ffff9d2c)[iVar1] * 0x100] =
       (&DAT_ffe61108)[(uint)(byte)(&DAT_ffff9d2c)[iVar1] * 0x100] |
       (byte)(1 << ((byte)(&DAT_ffff9d2d)[iVar1] & 0x1f));
  return;
}


/* ===== FUN_0001bd38 @ 0x1bd38 ===== */

void FUN_0001bd38(void)

{
  ushort uVar1;
  uint uVar2;
  
  DAT_ffff968a = 0xff;
  DAT_ffff968b = 0xff;
  Ramffff9678 = 0xfffffff;
  Ramffff967c = 0xffffffff;
  Ramffff95ac = 0xffffffff;
  DAT_ffff968c = 0;
  uVar2 = 0;
  DAT_ffff968d = 0;
  DAT_ffff968e = 0;
  DAT_ffff9693 = 0;
  DAT_ffff9694 = 0;
  do {
    *(undefined2 *)(&DAT_ffff9684 + uVar2 * 2) = 0xffff;
    uVar2 = uVar2 + 1;
  } while (uVar2 < 3);
  uVar1 = DAT_ffe61500;
  DAT_ffff95b4 = 0;
  DAT_ffff9698 = 0;
  DAT_ffff968f = 0;
  DAT_ffff9690 = 0;
  DAT_ffff9691 = 0;
  DAT_ffff9692 = 0;
  Ramffff9680 = 0xffff;
  DAT_ffe61500 = uVar1 & 0xbfff;
  FUN_00012dde(4,1);
  FUN_00012e8e(4,1);
  FUN_00012e50(4,2);
  FUN_00012e44(4,0x140);
  FUN_0001b92e();
  return;
}


/* ===== FUN_0001bdd4 @ 0x1bdd4 ===== */

void FUN_0001bdd4(void)

{
  undefined1 uVar1;
  
  DAT_ffe6020a = 0xbf;
  uVar1 = DAT_ffe6020a;
  __synchronize();
  FUN_0001b988();
  FUN_00012ece(4);
  FUN_00012f0a(4,1);
  FUN_0001b918(0x13);
  FUN_0001b8ba(0x13,1);
  FUN_0001b620(0x24,1);
  FUN_0001b7b6(0x24);
  return;
}


/* ===== FUN_0001c388 @ 0x1c388 ===== */

void FUN_0001c388(uint param_1,char param_2)

{
  if (param_2 == '\0') {
    FUN_00026b50();
    __synchronize();
  }
  else {
    FUN_00026b4a(&DAT_ffe62116 + ((param_1 & 0xff) >> 2) * 0x80);
    FUN_0001d87c((param_1 & 0xff) + 0xf2,1);
  }
  return;
}


/* ===== FUN_0001c428 @ 0x1c428 ===== */

void FUN_0001c428(uint param_1)

{
  *(short *)(&DAT_ffe62112 + ((param_1 & 0xff) >> 2) * 0x100) = (short)(1 << (param_1 & 3));
  __synchronize();
  return;
}


/* ===== FUN_0001c5ac @ 0x1c5ac ===== */

void FUN_0001c5ac(uint param_1,char param_2)

{
  byte bVar1;
  int iVar2;
  
  iVar2 = ((param_1 & 0xff) >> 2) * 0x100;
  if (param_2 == '\x01') {
    bVar1 = (&DAT_ffe62114)[iVar2] | (byte)(1 << (param_1 & 3));
  }
  else {
    bVar1 = (&DAT_ffe62114)[iVar2] & ~(byte)(1 << (param_1 & 3));
  }
  (&DAT_ffe62114)[iVar2] = bVar1;
  return;
}


/* ===== FUN_0001ca8a @ 0x1ca8a ===== */

void FUN_0001ca8a(uint param_1,ushort param_2)

{
  ushort uVar1;
  int iVar2;
  uint in_PSW;
  
  __disable_irq();
  uVar1 = (ushort)(1 << (param_1 & 3));
  iVar2 = ((param_1 & 0xff) >> 2) * 0x100;
  *(ushort *)(&DAT_ffe6210c + iVar2) =
       (param_2 & 0xff) * uVar1 + (*(ushort *)(&DAT_ffe6210c + iVar2) & ~uVar1) + -0x6400;
  if ((in_PSW & 0x20) == 0) {
    __enable_irq();
  }
  return;
}


/* ===== FUN_0001cb80 @ 0x1cb80 ===== */

void FUN_0001cb80(uint param_1,undefined2 param_2)

{
  *(undefined2 *)(&DAT_ffe63058 + (param_1 & 0x3f) * 0x40) = param_2;
  return;
}


/* ===== FUN_0001ccda @ 0x1ccda ===== */

void FUN_0001ccda(uint param_1)

{
  (&DAT_ffe63046)[(param_1 & 0x3f) * 0x40] = 4;
  __synchronize();
  return;
}


/* ===== FUN_0001cd14 @ 0x1cd14 ===== */

void FUN_0001cd14(uint param_1,undefined2 param_2)

{
  if ((param_1 & 0xff) >> 6 == 1) {
    *(undefined2 *)(&DAT_ffe6304a + (param_1 & 0x3f) * 0x40) = param_2;
    return;
  }
  *(undefined2 *)(&UNK_ffe60672 + (param_1 & 3) * 4 + ((param_1 & 0x3f) >> 2) * 0x80) = param_2;
  return;
}


/* ===== FUN_0001cd48 @ 0x1cd48 ===== */

void FUN_0001cd48(uint param_1,char param_2)

{
  int iVar1;
  
  iVar1 = (param_1 & 0x3f) * 0x40;
  (&DAT_ffe63042)[iVar1] = 0;
  (&DAT_ffe63044)[iVar1] = 0x77;
  (&DAT_ffe63040)[iVar1] = ((&DAT_ffe63040)[iVar1] & 0xe0) + param_2 + '\x14';
  return;
}


/* ===== FUN_0001ce48 @ 0x1ce48 ===== */

void FUN_0001ce48(uint param_1,ushort param_2)

{
  int iVar1;
  int iVar2;
  uint in_PSW;
  
  __disable_irq();
  iVar2 = ((param_1 & 0x3f) >> 2) * 0x80;
  iVar1 = (param_1 & 3) << 2;
  *(ushort *)(&DAT_ffe60628 + iVar2) =
       (short)(1 << iVar1) * (param_2 & 0xff) |
       ~(ushort)(0xf << iVar1) & *(ushort *)(&DAT_ffe60628 + iVar2);
  if ((in_PSW & 0x20) == 0) {
    __enable_irq();
  }
  return;
}


/* ===== FUN_0001ceda @ 0x1ceda ===== */

uint FUN_0001ceda(uint param_1)

{
  return (uint)*(ushort *)(&DAT_ffe60626 + ((param_1 & 0x3f) >> 2) * 0x80) & 1 << (param_1 & 3) &
         0xff;
}


/* ===== FUN_0001cef8 @ 0x1cef8 ===== */

void FUN_0001cef8(uint param_1)

{
  int iVar1;
  
  iVar1 = ((param_1 & 0x3f) >> 2) * 0x80;
  *(ushort *)(&DAT_ffe60622 + iVar1) =
       *(ushort *)(&DAT_ffe60622 + iVar1) | (ushort)(1 << (param_1 & 3));
  __synchronize();
  return;
}


/* ===== FUN_0001d11a @ 0x1d11a ===== */

void FUN_0001d11a(uint param_1,ushort param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint in_PSW;
  
  uVar2 = param_1 & 3;
  __disable_irq();
  uVar1 = (param_1 & 0xff) >> 2;
  *(ushort *)(&DAT_ffe60628 + uVar1 * 0x80) =
       (short)(1 << (uVar2 << 2)) * (param_2 & 0xff) |
       ~(ushort)(0xf << (uVar2 << 2)) & *(ushort *)(&DAT_ffe60628 + uVar1 * 0x80);
  (&DAT_ffe60634)[uVar1 * 0x40] = (&DAT_ffe60634)[uVar1 * 0x40] & ~(ushort)(1 << uVar2);
  __synchronize();
  uVar3 = *(ushort *)(&DAT_ffff9d7c + uVar1 * 2) + uVar2 & 0xffff;
  FUN_0001d7ca(uVar3);
  FUN_0001d87c(uVar3,1);
  (&DAT_ffe60624)[uVar1 * 0x40] = (ushort)(0x10 << uVar2) | (&DAT_ffe60624)[uVar1 * 0x40];
  __synchronize();
  if ((in_PSW & 0x20) == 0) {
    __enable_irq();
  }
  return;
}


/* ===== FUN_0001d96e @ 0x1d96e ===== */

void FUN_0001d96e(byte param_1)

{
  undefined2 *puVar1;
  
  if (param_1 < 8) {
    puVar1 = &DAT_ffe63900;
  }
  else {
    param_1 = param_1 - 8;
    puVar1 = (undefined2 *)((int)&DAT_ffe63900 + 1);
  }
  FUN_00026b4a(puVar1,param_1);
  return;
}


/* ===== FUN_0001d996 @ 0x1d996 ===== */

void FUN_0001d996(byte param_1)

{
  undefined2 uVar1;
  undefined2 *puVar2;
  
  if (param_1 < 8) {
    puVar2 = &DAT_ffe63900;
  }
  else {
    param_1 = param_1 - 8;
    puVar2 = (undefined2 *)((int)&DAT_ffe63900 + 1);
  }
  FUN_00026b50(puVar2,param_1);
  uVar1 = DAT_ffe63900;
  __synchronize();
  return;
}


/* ===== FUN_0001da38 @ 0x1da38 ===== */

void FUN_0001da38(uint param_1,undefined2 param_2)

{
  *(undefined2 *)(&DAT_ffe63918 + (param_1 & 0xff) * 0x10) = param_2;
  return;
}


/* ===== FUN_0001da50 @ 0x1da50 ===== */

void FUN_0001da50(uint param_1,undefined2 param_2)

{
  *(undefined2 *)(&DAT_ffe63914 + (param_1 & 0xff) * 0x10) = param_2;
  return;
}


/* ===== FUN_0001da5c @ 0x1da5c ===== */

undefined4 FUN_0001da5c(void)

{
  undefined4 uVar1;
  
  uVar1 = DAT_ffe60220;
  return uVar1;
}


/* ===== FUN_0001da64 @ 0x1da64 ===== */

int FUN_0001da64(void)

{
  int iVar1;
  
  iVar1 = DAT_ffe60220;
  return iVar1 << 8;
}


/* ===== FUN_0001da6e @ 0x1da6e ===== */

int FUN_0001da6e(uint param_1)

{
  return *(int *)(&DAT_ffe60638 + ((param_1 & 0xff) >> 2) * 0x80) << 8;
}


/* ===== FUN_0001eb2a @ 0x1eb2a ===== */

void FUN_0001eb2a(void)

{
  int iVar1;
  undefined8 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  uVar2 = 0;
  FUN_0001ea70(&DAT_ffe60000,0x3ff);
  FUN_0001ea98(&DAT_ffe60002,4);
  FUN_0001ea98(&DAT_ffe60003,0x8e);
  FUN_0001ea70(&DAT_ffe60080,0);
  FUN_0001ea70(&DAT_ffe60084,9);
  FUN_0001ea70(&DAT_ffe60088,0);
  FUN_0001ea70(&DAT_ffe6008c,0);
  FUN_0001ea98(&DAT_ffe60200,1);
  FUN_0001eac0(&DAT_ffe60214,0x3f);
  FUN_0001ea98(&DAT_ffe60400,0x55);
  FUN_0001ea98(&DAT_ffe60600,0x3f);
  iVar5 = 0;
  do {
    FUN_0001ea98(&DAT_ffe60604 + iVar5,0xf);
    FUN_0001eae6(&DAT_ffe60624 + iVar5 * 0x40,
                 *(undefined2 *)(&DAT_ffff9dd4 + iVar5 * 2 + (int)((ulonglong)uVar2 >> 0x20)),0x10f)
    ;
    FUN_0001eac0(&DAT_ffe6063c + iVar5 * 0x40,0x1000000);
    iVar4 = iVar5 + 1;
    iVar1 = iVar5 + -5;
    iVar3 = iVar5 + -5;
    iVar5 = iVar4;
  } while (iVar1 < 0 != (iVar4 < 0 && -1 < iVar3));
  FUN_0001ea70(&DAT_ffe61000,0x1f);
  iVar5 = 0;
  do {
    iVar3 = iVar5 * 0x100;
    FUN_0001ea98(&DAT_ffe61111 + iVar3,0);
    FUN_0001ea98(&DAT_ffe61110 + iVar3,0);
    FUN_0001ea98(&DAT_ffe61114 + iVar3,(&DAT_ffff9dea)[iVar5 + (int)((ulonglong)uVar2 >> 0x20)]);
    FUN_0001eac0(&DAT_ffe61128 + iVar5 * 0x80,0x1000000);
    FUN_0001eac0(&DAT_ffe6112c + iVar5 * 0x80,0x1000000);
    FUN_0001ea98(&DAT_ffe61130 + iVar3,0);
    FUN_0001ea98(&DAT_ffe61134 + iVar3,0);
    iVar4 = iVar5 + 1;
    iVar1 = iVar5 + -4;
    iVar3 = iVar5 + -4;
    iVar5 = iVar4;
  } while (iVar1 < 0 != (iVar4 < 0 && -1 < iVar3));
  FUN_0001ea98(&DAT_ffe62000,0x7f);
  iVar5 = 0;
  do {
    FUN_0001ea98(&DAT_ffe62108 + iVar5 * 0x100,1);
    FUN_0001ea98(&DAT_ffe62104 + iVar5 * 0x100,0);
    iVar4 = iVar5 + 1;
    iVar1 = iVar5 + -6;
    iVar3 = iVar5 + -6;
    iVar5 = iVar4;
  } while (iVar1 < 0 != (iVar4 < 0 && -1 < iVar3));
  FUN_0001ea70(&DAT_ffe63000,0xfff);
  FUN_0001ea70(&DAT_ffe6300c,0xfff);
  iVar5 = 0;
  do {
    FUN_0001ea98(&DAT_ffe63910 + iVar5 * 0x10,
                 (&DAT_ffff9def)[iVar5 + (int)((ulonglong)uVar2 >> 0x20)]);
    iVar4 = iVar5 + 1;
    iVar1 = iVar5 + -7;
    iVar3 = iVar5 + -7;
    iVar5 = iVar4;
  } while (iVar1 < 0 != (iVar4 < 0 && -1 < iVar3));
  FUN_0001ea98(&DAT_ffe60100,0x10);
  FUN_0001ea98(&DAT_ffe63c00,0);
  return;
}


/* ===== FUN_0001f5b0 @ 0x1f5b0 ===== */

void FUN_0001f5b0(void)

{
  int iVar1;
  int iVar2;
  byte bVar3;
  int iVar4;
  int iVar5;
  
  DAT_ffe60002 = 4;
  DAT_ffe60003 = 0x8e;
  DAT_ffe60080 = 0;
  DAT_ffe60084 = 9;
  DAT_ffe60088 = 0;
  DAT_ffe6008c = 0;
  DAT_ffe60200 = 1;
  DAT_ffe60214 = 0x3f;
  DAT_ffe60400 = 0x55;
  bVar3 = DAT_ffe60402;
  DAT_ffe60402 = bVar3 | 0x40;
  iVar5 = 0;
  do {
    (&DAT_ffe6063c)[iVar5 * 0x40] = 0;
    (&DAT_ffe60624)[iVar5 * 0x40] = *(undefined2 *)(&DAT_ffff9dd4 + iVar5 * 2);
    (&DAT_ffe60604)[iVar5] = 0xf;
    iVar4 = iVar5 + 1;
    (&DAT_ffe60634)[iVar5 * 0x40] = 0;
    iVar2 = iVar5 + -5;
    iVar1 = iVar5 + -5;
    iVar5 = iVar4;
  } while (iVar2 < 0 != (iVar4 < 0 && -1 < iVar1));
  iVar5 = 0;
  do {
    (&DAT_ffe61100)[iVar5 * 0x80] = *(undefined2 *)(&DAT_ffff9de0 + iVar5 * 2);
    iVar4 = iVar5 + 1;
    iVar2 = iVar5 + -4;
    iVar1 = iVar5 + -4;
    (&DAT_ffe61114)[iVar5 * 0x100] = (&DAT_ffff9dea)[iVar5];
    (&DAT_ffe61128)[iVar5 * 0x80] = 0;
    (&DAT_ffe6112c)[iVar5 * 0x80] = 0;
    iVar5 = iVar4;
  } while (iVar2 < 0 != (iVar4 < 0 && -1 < iVar1));
  iVar5 = 0;
  do {
    iVar4 = iVar5 + 1;
    (&DAT_ffe62108)[iVar5 * 0x100] = 1;
    (&DAT_ffe62104)[iVar5 * 0x100] = 0;
    (&DAT_ffe62116)[iVar5 * 0x80] = 0;
    iVar2 = iVar5 + -6;
    iVar1 = iVar5 + -6;
    iVar5 = iVar4;
  } while (iVar2 < 0 != (iVar4 < 0 && -1 < iVar1));
  DAT_ffe6300c = 0xfff;
  DAT_ffe63010 = 0xc901;
  iVar5 = 0;
  do {
    iVar4 = iVar5 + 1;
    (&DAT_ffe63040)[iVar5 * 0x40] = 0x20;
    (&DAT_ffe63047)[iVar5 * 0x40] = 0;
    iVar2 = iVar5 + -0xb;
    iVar1 = iVar5 + -0xb;
    iVar5 = iVar4;
  } while (iVar2 < 0 != (iVar4 < 0 && -1 < iVar1));
  iVar5 = 0;
  do {
    iVar4 = iVar5 + 1;
    iVar2 = iVar5 + -7;
    iVar1 = iVar5 + -7;
    (&DAT_ffe63910)[iVar5 * 0x10] = (&DAT_ffff9def)[iVar5];
    iVar5 = iVar4;
  } while (iVar2 < 0 != (iVar4 < 0 && -1 < iVar1));
  DAT_ffe60100 = 0x10;
  DAT_ffe60000 = 0x3ff;
  return;
}


/* ===== FUN_0001f76a @ 0x1f76a ===== */

void FUN_0001f76a(void)

{
  undefined4 uVar1;
  
  DAT_ffe60000 = 0;
  DAT_ffe60600 = 0x3f;
  DAT_ffe61000 = 0x1f;
  DAT_ffe62000 = 0x7f;
  DAT_ffe63000 = 0xfff;
  DAT_ffe63c00 = 0;
  DAT_ffe60220._0_2_ = 0;
  uVar1 = DAT_ffe60220;
  __synchronize();
  DAT_ffe60000 = 0x3ff;
  return;
}


/* ===== FUN_0002175e @ 0x2175e ===== */

void FUN_0002175e(void)

{
  DAT_ffe60000 = 0;
  DAT_ffe60600 = 0;
  DAT_ffe61000 = 0;
  DAT_ffe62000 = 0;
  DAT_ffe63000 = 0;
  DAT_ffe63c00 = 0;
  return;
}


/* ===== FUN_000b7e68 @ 0xb7e68 ===== */

undefined4 FUN_000b7e68(void)

{
  undefined4 uVar1;
  
  uVar1 = DAT_ffe60220;
  return uVar1;
}


/* ===== FUN_000b7f64 @ 0xb7f64 ===== */

void FUN_000b7f64(void)

{
  ushort uVar1;
  
  uVar1 = DAT_ffe60000;
  DAT_ffe60000 = uVar1 & 0xffef;
  DAT_ffe61000 = 0;
  return;
}


